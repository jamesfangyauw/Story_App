package com.intermediate.substory.view.main

import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Toast
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.intermediate.substory.RecyclerViewAdapter
import com.intermediate.substory.databinding.ActivityMainBinding
import com.intermediate.substory.model.StoryModel
import com.intermediate.substory.model.UserPreference
import com.intermediate.substory.view.ViewModelFactory
import com.intermediate.substory.view.add.UploadNewStory
import com.intermediate.substory.view.detail.DetailActivity
import com.intermediate.substory.view.welcome.WelcomeActivity

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class MainActivity : AppCompatActivity() {
    private lateinit var mainViewModel: MainViewModel
    private lateinit var binding: ActivityMainBinding
    private val recyclerViewAdapter by lazy { RecyclerViewAdapter() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

//        binding.rvItem.layoutManager = LinearLayoutManager(this)

//        setupView()
        setupViewModel()
        setupAction()



    }

    private fun setupView() {
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
        supportActionBar?.hide()
    }

    private fun setupViewModel() {
        mainViewModel = ViewModelProvider(
            this,
            ViewModelFactory(UserPreference.getInstance(dataStore))
        )[MainViewModel::class.java]

        val id = intent.getStringExtra(ID_USER)

        mainViewModel.getUser().observe(this) { user ->
            if (user.isLogin) {
                mainViewModel.getAllStories("Bearer ${user.token}").observe(this) { result ->
                    if (result != null) {
                        when (result) {
                            is com.intermediate.substory.ResultCustom.Loading -> binding.pbMain.visibility = View.VISIBLE
                            is com.intermediate.substory.ResultCustom.Success -> {
                                Log.d("username", "${user.name}")
                                binding.pbMain.visibility = View.GONE

                                binding.rvItem.layoutManager = LinearLayoutManager(this)
                                val userList = ArrayList<StoryModel>()
                                for (user in result.data) {
                                    val item = StoryModel( user.name, user.photoUrl, user.id)
                                    userList.add(item)
                                }
                                binding.rvItem.adapter = recyclerViewAdapter
                                Log.d("userlist", "$userList")
                                recyclerViewAdapter.setData(userList)

                                recyclerViewAdapter.setOnItemClickCallback(object : RecyclerViewAdapter.OnItemClickCallback {
                                    override fun onItemClicked(data: StoryModel) {
                                        val intentToDetail = Intent(this@MainActivity, DetailActivity::class.java)
                                        intentToDetail.putExtra(DetailActivity.ID, data.id)
                                        intentToDetail.putExtra(DetailActivity.TOKEN, "Bearer ${user.token}")
                                        startActivity(intentToDetail)
                                    }
                                })

                            }
                            is com.intermediate.substory.ResultCustom.Error -> {
                                binding.pbMain.visibility = View.GONE
                                View.GONE
                                Toast.makeText(
                                    this@MainActivity,
                                    "Terjadi kesalahan" + result.error,
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    }
                }
            } else {
                startActivity(Intent(this, WelcomeActivity::class.java))
                finish()
            }

            binding.addStory.setOnClickListener {
                val intentToAddStory = Intent(this@MainActivity, UploadNewStory::class.java)
                intentToAddStory.putExtra(UploadNewStory.TOKEN_USER, "Bearer ${user.token}")
                startActivity(intentToAddStory)
            }
        }
    }

    private fun setupAction() {
        binding.logoutButton.setOnClickListener {
            mainViewModel.logout()
        }
    }

    companion object {
        val ID_USER = "ID USER"
    }


}