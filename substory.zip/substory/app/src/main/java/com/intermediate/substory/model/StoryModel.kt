package com.intermediate.substory.model

data class StoryModel(
    val name: String,
    val photoUrl: String,
    val id: String,
)

data class StoryResponse(
    val error: Boolean,
    val message: String,
    val listStory: List<StoryModel>?
)