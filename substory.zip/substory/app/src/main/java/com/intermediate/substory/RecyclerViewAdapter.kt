package com.intermediate.substory

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.intermediate.substory.databinding.ActivityItemBinding
import com.intermediate.substory.model.StoryModel

class RecyclerViewAdapter() :
    RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>() {
    private var listItem: List<StoryModel> = emptyList<StoryModel>()
    private lateinit var itemUserBinding: ActivityItemBinding
    private lateinit var onItemClickCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    class ViewHolder(var itemUserBinding: ActivityItemBinding) :
        RecyclerView.ViewHolder(itemUserBinding.root)

    interface OnItemClickCallback {
        fun onItemClicked(data: StoryModel)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        itemUserBinding =
            ActivityItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(itemUserBinding)
    }

    override fun getItemCount(): Int = listItem.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val (username, photo) = listItem[position]
        Glide.with(holder.itemView.context).load(photo)
            .into(holder.itemUserBinding.ivPhotoItem)
        holder.itemUserBinding.tvNameUser.text = username
        holder.itemView.setOnClickListener { onItemClickCallback.onItemClicked(listItem[holder.adapterPosition]) }
    }

    fun setData(newData: List<StoryModel>) {
        val recipesDiffUtil = DiffUtilStories(listItem, newData)
        val diffUtilResult = DiffUtil.calculateDiff(recipesDiffUtil)
        listItem = newData
        diffUtilResult.dispatchUpdatesTo(this)
    }

}